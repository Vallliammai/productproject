import { Component, Input, OnInit } from '@angular/core';
import { ProductitemService } from '../services/productitem/productitem.service';
import { Productss } from '../shared/models/productss';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styles: [
  ]
})
export class HomeComponent implements OnInit {
  @Input()
  taskList: string[] = [];
products:Productss[] = [];
 
  constructor(private productitemservice:ProductitemService) { }

  ngOnInit(): void {
    //this.products = this.productitemservice.getAll();
    this.productitemservice.getAll()
    .subscribe(data => this.products=data);
  }
onSubmit(){

}
}
