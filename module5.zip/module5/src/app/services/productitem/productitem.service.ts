import { Injectable } from '@angular/core';
import { Productss } from 'src/app/shared/models/productss';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductitemService {
private _url:string = 'assets/data/productss.json'
  constructor(private http:HttpClient) { }
 getAll():Observable<Productss[]>{
return this.http.get<Productss[]>(this._url);
 }
 //:Productss[]{
//     return [
//       {
//         id:1,
//         name:'Nokia',
//         price:8999,
// favourite:false,
// imageUrl:'assets/phone.jpg',
// tags:['offer'],
// stars:4.5,

//       },
//       {
//         id:2,
//         name:'Samsung',
//         price:1999,
// favourite:false,
// imageUrl:'assets/phone.jpg',
// tags:['offer'],
// stars:4,

//       },
//       {
//         id:3,
//         name:'Vivo',
//         price:10999,
// favourite:false,
// imageUrl:'assets/phone.jpg',
// tags:['offer'],
// stars:4.5,

//       }
    
//     ]
//     }
}
