import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styles: [
  ]
})
export class ProductComponent implements OnInit {

  constructor(private router:Router,) { }
onSubmit(){
  this.router.navigate(['/productdetail'])
}
onSubmit1(){
  this.router.navigate(['/product1'])
}
onSubmit2(){
  this.router.navigate(['/product2'])
}
onSubmit3(){
  this.router.navigate(['/product3'])
}
  ngOnInit(): void {
  }



}
